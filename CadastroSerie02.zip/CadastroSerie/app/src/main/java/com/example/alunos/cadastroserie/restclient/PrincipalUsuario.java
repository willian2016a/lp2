package br.com.herbertrausch;

import br.com.herbertrausch.rest.RestFulClient;

public class PrincipalUsuario{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestFulClient ws = new RestFulClient();
		
		
		
		//Recuperando todos os Usuários através do nickname
		//String nickname = null;
		String json = ws.recuperarDados("http://localhost:8080/restmongo/rest/usuarios/nickname/pagodeiro");
		System.out.println(json);
		
	 
		//Recuperando todos as Séries
		//Por gênero
		//String genero = null;
		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/series/Genero/Aventura");
		System.out.println(json);
		
		//Por nome
		//String nome = null;
		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/series/Serie/Arrow");
		System.out.println(json);
		
		
		//Recuperando todos os Episódios
		//String nomeEpisodio = null;
		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/episodios/nomeEpisodio/legal2");
		System.out.println(json);
		
		
		
		
		
		//Salvar dados da Série
		ws.salvar("http://localhost:8080/restmongo/rest/episodios", "{nomeEpisodio: 'teste ws'}");
        
		//Salvar dados do Episódio
	    ws.salvar("http://localhost:8080/restmongo/rest/usuarios", "{nickname: QualquerCoisa}");

	  //Salvar dados do Usuário
	   ws.salvar("http://localhost:8080/restmongo/rest/series", "{nomeSerie: ...}");
	    
	    
	   
		
		//transformando em objetos
		// ArrayList<Endereco> e1 = Endereco.fromArrayJson(json);
		///for(Endereco e: e1){
      	//System.out.println(e.getRua());
		//
	   //System.out.println(e.getEstado());
		//}
		//Salvando endereco
		//e1.setCidade("Varginha");
	   //e1.setRua("Imigrante Cliente2");
		
       //ws.salvarEndereco(e1);
		
		ws.closeConnection();
		

	}

}