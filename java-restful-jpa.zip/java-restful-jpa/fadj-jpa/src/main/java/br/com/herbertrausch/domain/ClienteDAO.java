package br.com.herbertrausch.domain;



public class ClienteDAO extends GenericDAO<Cliente> {

	public ClienteDAO() {
		super(Cliente.class);
	}
	


}
