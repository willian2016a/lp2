package fadjjdbc;



public class PersistenceTest {


	public static void main(String[] args) throws Exception {
		
//		ApplicationContext ctx = 
//	            new AnnotationConfigApplicationContext(AppConfig.class);
//		HostingBo hostingBo = (HostingBo) ctx.getBean("hostingBoImpl");
//		
//		System.out.println("1");
//		
//			hostingBo.save("cloud.google.com");
//			hostingBo.save("heroku.com");
//			hostingBo.save("cloudbees.com");

		
	
	}
	
	


}


