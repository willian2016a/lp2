package br.com.herbertrausch.rest;


//@Path("/clientes")
//@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
//@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class ClientesResourceDriver {
	
//	ClienteDao cdao = new ClienteDao();
//
//	@GET
//	public List<Document> get() {
//		
//		return cdao.get();
//		
//	}
//
//	@GET
//	@Path("{nome}")
//	public List<Document> get(@PathParam("nome") String nome) {
//		
//		return cdao.getByNome(nome);
//	}

	
//	@POST
//	public void save(Cliente c) throws ParseException{
//		
//		cdao.save(c);
//		
//	}
	

}
