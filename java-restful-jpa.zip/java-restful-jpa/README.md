# java-restful-jpa
In this project I present a JAVA Web Service Layer and JPA application..
