package br.com.herbertrausch;

import java.util.ArrayList;

import br.com.herbertrausch.domain.Endereco;
import br.com.herbertrausch.rest.RestFulClient;

public class PrincipalUsuario{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RestFulClient ws = new RestFulClient();
		
		
		//Recuperando todos os Usuários
		String json = ws.recuperarDados("http://localhost:8080/restmongo/rest/clientes");
		System.out.println(json);
		
		
		//Recuperando todos as Séries
		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/series");
		System.out.println(json);
		
//		String nomeSerie = "Deadpool"; 
//		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/series/nomede/"+nomeSerie);
//		System.out.println(json);
		
	
		//Recuperando todos os Episódios
		json = ws.recuperarDados("http://localhost:8080/restmongo/rest/episodios");
		System.out.println(json);
		
		/////////////////////////////////////
//		ws.salvar("http://localhost:8080/restmongo/rest/usuarios", "{nome: Herbert, email:}");
//		
//		
//		//Recuperando todos as Series
		ws.salvar("http://localhost:8080/restmongo/rest/series", "{nomeSerie: ...}");
//		System.out.println(json);
//		
//		//Recuperando todos os Episódios
//		json = ws.salvarDados("http://localhost:8080/restmongo/rest/episodios");
//		System.out.println(json);
		
		
		//transformando em objetos
		
		// ArrayList<Endereco> e1 = Endereco.fromArrayJson(json);
		
		///for(Endereco e: e1){
			//System.out.println(e.getRua());
		//
			//System.out.println(e.getEstado());
		//}
		//Salvando endereco
		

//		
//		e1.setCidade("Varginha");
//		e1.setRua("Imigrante Cliente2");
		
//		ws.salvarEndereco(e1);
		
		ws.closeConnection();
		

	}

}