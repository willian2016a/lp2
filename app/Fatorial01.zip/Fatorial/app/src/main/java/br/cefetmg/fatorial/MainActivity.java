package br.cefetmg.fatorial;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calcularFatorial(View view){
        EditText nu = (EditText) findViewById(R.id.editTextNumero);
        String num = nu.getText().toString();
        int n = Integer.parseInt(num);

        int z=n;

        while(n>1){
            z=z*(n-1);
        }

        EditText resultado = (EditText) findViewById(R.id.editTextResultado);
        resultado.setText(String.valueOf(n));

    }

}
